import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {

  public authorized = false;    
  constructor() { }

}
